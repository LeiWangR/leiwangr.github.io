MISSION CONTROL v8.0 - SUPPORT FILES
=======================================

Files included:

1. mission_history.txt
   A clean history file.
   Put it in the same folder as mission_control_v8.py to start with
   existing readings.

2. mission_report.txt
   Example report generated from the sample history.

3. mission_history_malformed.txt
   Deliberately contains malformed/invalid records.
   Use it to demonstrate FileNotFoundError/ValueError handling and
   the loader's warning messages.

4. mission_history_edge_cases.txt
   Small test set covering temperatures at 0, 80, just above 80,
   100, and just below 100.

Recommended steps:
- Start with mission_history.txt.
- Run Mission Control and try: history, report, recent, warning,
  critical, top3, preview.
- Run scan and restart the program to demonstrate persistence.
- Try save and newreport.
- Temporarily use mission_history_malformed.txt as the history file
  to demonstrate defensive programming.
- Use mission_history_edge_cases.txt to test classification boundaries.

Keep all files in the same folder as mission_control_v8.py.

10 Sep 2026
