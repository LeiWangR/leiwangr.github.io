# ============================================================
# MISSION CONTROL v8.0
# Week 8: Files, Exceptions and Debugging
# Based on Mission Control v7.0
# ============================================================

import sys

HISTORY_FILE = "mission_history.txt"
REPORT_FILE = "mission_report.txt"


def show_header(title):
    print("=" * 60)
    print(title.center(60))
    print("=" * 60)


def classify_temperature(temperature):
    if temperature < 0:
        return "INVALID"
    elif temperature >= 100:
        return "CRITICAL"
    elif temperature > 80:
        return "WARNING"
    else:
        return "SAFE"


def format_reading(reading):
    sensor_number, temperature, status = reading
    return f"Sensor {sensor_number:<2} | {temperature:>6.1f} C | {status:<8}"


def load_history(filename):
    reading_history = []

    try:
        with open(filename, "r") as file:
            for line in file:
                line = line.strip()

                if line == "":
                    continue

                parts = line.split("|")

                if len(parts) != 3:
                    print(
                        f"Warning: skipped malformed line: {line}",
                        file=sys.stderr
                    )
                    continue

                try:
                    sensor_number = int(parts[0])
                    temperature = float(parts[1])
                    status = parts[2]

                    if status not in ("SAFE", "WARNING", "CRITICAL"):
                        raise ValueError("invalid status")

                    reading = (sensor_number, temperature, status)
                    reading_history.append(reading)

                except ValueError:
                    print(
                        f"Warning: skipped invalid reading: {line}",
                        file=sys.stderr
                    )

    except FileNotFoundError:
        print(
            f"No existing history file found. Starting a new mission log."
        )

    return reading_history


def append_history(filename, readings):
    with open(filename, "a") as file:
        for sensor_number, temperature, status in readings:
            file.write(
                f"{sensor_number}|{temperature}|{status}\n"
            )


def save_report(filename, report_lines):
    with open(filename, "w") as file:
        file.write("\n".join(report_lines))
        file.write("\n")


def create_new_report(filename, report_lines):
    try:
        with open(filename, "x") as file:
            file.write("\n".join(report_lines))
            file.write("\n")
        print(f"New report created: {filename}")
    except FileExistsError:
        print(
            f"Report '{filename}' already exists. "
            "Use the save command to replace it."
        )


def scan_sensors():
    scan_readings = []
    safe_count = 0
    warning_count = 0

    for sensor_number in range(1, 6):
        while True:
            try:
                temperature = float(
                    input(f"Sensor {sensor_number} temperature: ")
                )
                break
            except ValueError:
                print("Invalid temperature. Please enter a number.")

        status = classify_temperature(temperature)

        if status == "INVALID":
            print("Invalid reading - skipped.")
            continue

        reading = (sensor_number, temperature, status)
        scan_readings.append(reading)

        if status == "CRITICAL":
            print("CRITICAL - scan stopped")
            warning_count += 1
            break
        elif status == "WARNING":
            print("WARNING")
            warning_count += 1
        else:
            print("SAFE")
            safe_count += 1

    return scan_readings, safe_count, warning_count


def show_report(reading_history):
    print("\n--- CURRENT REPORT ---")
    total_valid = len(reading_history)
    print(f"Valid readings: {total_valid}")

    if not reading_history:
        print("No valid sensor data yet.")
        return []

    temperatures = [reading[1] for reading in reading_history]
    statuses = [reading[2] for reading in reading_history]

    safe_count = statuses.count("SAFE")
    warning_count = statuses.count("WARNING")
    critical_count = statuses.count("CRITICAL")

    average = sum(temperatures) / len(temperatures)

    report_lines = [
        "--- CURRENT REPORT ---",
        f"Valid readings: {total_valid}",
        f"Safe readings: {safe_count}",
        f"Warnings: {warning_count}",
        f"Critical readings: {critical_count}",
        f"Average: {average:.1f} C",
        f"Highest: {max(temperatures):.1f} C",
        f"Lowest: {min(temperatures):.1f} C"
    ]

    for line in report_lines[1:]:
        print(line)

    return report_lines


def show_history(reading_history):
    print("\n--- READING HISTORY ---")

    if not reading_history:
        print("No valid sensor readings recorded.")
        return

    lines = []
    for reading in reading_history:
        lines.append(format_reading(reading))

    print("\n".join(lines))


def show_recent(reading_history):
    print("\n--- RECENT READINGS ---")
    recent_readings = reading_history[-3:]

    if not recent_readings:
        print("No valid sensor readings recorded.")
        return

    for reading in recent_readings:
        print(format_reading(reading))


def show_status(reading_history, required_status):
    matching_readings = [
        reading
        for reading in reading_history
        if reading[2] == required_status
    ]

    print(f"\n--- {required_status} READINGS ---")

    if not matching_readings:
        print(f"No {required_status} readings recorded.")
        return

    for reading in matching_readings:
        print(format_reading(reading))


def show_highest_three(reading_history):
    print("\n--- HIGHEST THREE TEMPERATURES ---")

    if not reading_history:
        print("No valid sensor readings recorded.")
        return

    temperatures = [reading[1] for reading in reading_history]
    temperatures.sort()

    for temperature in temperatures[-3:][::-1]:
        print(f"{temperature:.1f} C")


def show_mission(mission_name, destination):
    print("\n--- MISSION INFORMATION ---")
    print(f"Mission: {mission_name}")
    print(f"Destination: {destination}")

    if len(mission_name) >= 3:
        print(f"Mission code: {mission_name[:3].upper()}")
    else:
        print("Mission code: " + mission_name.upper())


def search_history(reading_history):
    keyword = input("Search text: ").strip().lower()

    if keyword == "":
        print("Search text cannot be empty.")
        return

    matches = []

    for reading in reading_history:
        line = format_reading(reading)

        if keyword in line.lower():
            matches.append(line)

    print("\n--- SEARCH RESULTS ---")

    if not matches:
        print("No matching readings found.")
    else:
        print("\n".join(matches))


def status_command(reading_history):
    status = input(
        "Enter status (SAFE/WARNING/CRITICAL): "
    ).strip().upper()

    if status in ("SAFE", "WARNING", "CRITICAL"):
        show_status(reading_history, status)
    else:
        print("Invalid status.")


def build_log_lines(reading_history):
    lines = []

    for reading in reading_history:
        lines.append(format_reading(reading))

    return lines


def show_log(reading_history):
    print("\n--- MISSION LOG ---")

    if not reading_history:
        print("No valid sensor readings recorded.")
        return

    lines = build_log_lines(reading_history)
    log = "\n".join(lines)

    print(log)
    print(f"\nLog contains {len(lines)} readings.")


def save_current_report(reading_history):
    report_lines = show_report(reading_history)

    if not report_lines:
        return

    save_report(REPORT_FILE, report_lines)
    print(f"Report saved to {REPORT_FILE}.")


def create_report_file(reading_history):
    report_lines = show_report(reading_history)

    if not report_lines:
        return

    create_new_report(REPORT_FILE, report_lines)


def show_file_preview(filename):
    print(f"\n--- FILE PREVIEW: {filename} ---")

    try:
        with open(filename, "r") as file:
            lines = file.readlines()

        if not lines:
            print("File is empty.")
            return

        print(f"Lines in file: {len(lines)}")
        print("First two lines:")

        for line in lines[:2]:
            print(line.rstrip())

        if len(lines) > 2:
            print("Last two lines:")
            for line in lines[-2:]:
                print(line.rstrip())

    except FileNotFoundError:
        print(f"File '{filename}' was not found.")


def reset_history(filename):
    with open(filename, "w") as file:
        file.write("")

    print(f"History file '{filename}' has been cleared.")


def show_help():
    command_text = (
        "scan report history recent safe warning critical "
        "top3 mission search status log save newreport preview "
        "reset help shutdown"
    )

    commands = command_text.split()

    print("\n--- AVAILABLE COMMANDS ---")
    print(" | ".join(commands))


def run_mission_control():
    reading_history = load_history(HISTORY_FILE)

    mission_name = input("Mission name: ").strip().title()
    destination = input("Destination: ").strip().title()

    show_header(f"MISSION CONTROL v8.0 — {mission_name}")
    print(f"Destination: {destination}")
    print(f"Loaded {len(reading_history)} historical readings.")

    while True:
        command = input(
            "\nCommand [scan/report/history/recent/safe/warning/"
            "critical/top3/mission/search/status/log/save/newreport/"
            "preview/reset/help/shutdown]: "
        ).strip().lower()

        if command == "shutdown":
            print("Shutting down Mission Control...")
            break

        if command == "report":
            show_report(reading_history)
            continue

        if command == "history":
            show_history(reading_history)
            continue

        if command == "recent":
            show_recent(reading_history)
            continue

        if command == "safe":
            show_status(reading_history, "SAFE")
            continue

        if command == "warning":
            show_status(reading_history, "WARNING")
            continue

        if command == "critical":
            show_status(reading_history, "CRITICAL")
            continue

        if command == "top3":
            show_highest_three(reading_history)
            continue

        if command == "mission":
            show_mission(mission_name, destination)
            continue

        if command == "search":
            search_history(reading_history)
            continue

        if command == "status":
            status_command(reading_history)
            continue

        if command == "log":
            show_log(reading_history)
            continue

        if command == "save":
            save_current_report(reading_history)
            continue

        if command == "newreport":
            create_report_file(reading_history)
            continue

        if command == "preview":
            show_file_preview(HISTORY_FILE)
            continue

        if command == "reset":
            reset_history(HISTORY_FILE)
            reading_history = []
            continue

        if command == "help":
            show_help()
            continue

        if command != "scan":
            print("Unknown command.")
            continue

        scan_readings, scan_safe, scan_warning = scan_sensors()

        if scan_readings:
            reading_history.extend(scan_readings)
            append_history(HISTORY_FILE, scan_readings)

        print(
            f"Scan complete: {len(scan_readings)} valid readings, "
            f"{scan_safe} safe, {scan_warning} warning/critical."
        )

    print("=" * 60)
    print("SESSION ENDED".center(60))
    print("=" * 60)


run_mission_control()
